#include "crx_handler.h"
#include <iostream>

namespace superfast {

bool CRXHandler::install(const std::string& filePath) {
    std::cout << "Installing CRX extension: " << filePath << std::endl;
    // Implementasi parsing dan instalasi dari file CRX
    return true;
}

} // namespace superfast
