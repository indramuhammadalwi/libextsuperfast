#ifndef CRX_HANDLER_H
#define CRX_HANDLER_H

#include <string>

namespace superfast {

class CRXHandler {
public:
    bool install(const std::string& filePath);
};

} // namespace superfast

#endif // CRX_HANDLER_H
