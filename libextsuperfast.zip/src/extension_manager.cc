#include "extension_manager.h"
#include "chrome_extension_handler.h"
#include "zip_handler.h"
#include "crx_handler.h"

namespace superfast {

bool ExtensionManager::installFromWebStore(const std::string& extensionId) {
    ChromeExtensionHandler handler;
    return handler.downloadAndInstall(extensionId);
}

bool ExtensionManager::installFromCRX(const std::string& filePath) {
    CRXHandler handler;
    return handler.install(filePath);
}

bool ExtensionManager::installFromZIP(const std::string& filePath) {
    ZIPHandler handler;
    return handler.install(filePath);
}

std::vector<Extension> ExtensionManager::listExtensions() {
    // Implementasi daftar extension dari penyimpanan lokal
    return {};
}

bool ExtensionManager::runExtension(const std::string& extensionId) {
    // Implementasi menjalankan extension
    return true;
}

} // namespace superfast
