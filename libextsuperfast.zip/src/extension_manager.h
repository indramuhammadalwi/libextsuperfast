#ifndef EXTENSION_MANAGER_H
#define EXTENSION_MANAGER_H

#include <string>
#include <vector>
#include "libextsuperfast.h"

namespace superfast {

class ExtensionManager {
public:
    bool installFromWebStore(const std::string& extensionId);
    bool installFromCRX(const std::string& filePath);
    bool installFromZIP(const std::string& filePath);
    std::vector<Extension> listExtensions();
    bool runExtension(const std::string& extensionId);
};

} // namespace superfast

#endif // EXTENSION_MANAGER_H
