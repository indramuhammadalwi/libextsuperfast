#ifndef CHROME_EXTENSION_HANDLER_H
#define CHROME_EXTENSION_HANDLER_H

#include <string>

namespace superfast {

class ChromeExtensionHandler {
public:
    bool downloadAndInstall(const std::string& extensionId);
};

} // namespace superfast

#endif // CHROME_EXTENSION_HANDLER_H
