#ifndef ZIP_HANDLER_H
#define ZIP_HANDLER_H

#include <string>

namespace superfast {

class ZIPHandler {
public:
    bool install(const std::string& filePath);
};

} // namespace superfast

#endif // ZIP_HANDLER_H
