#include "file_utils.h"
#include <fstream>

namespace superfast {

bool FileUtils::fileExists(const std::string& path) {
    std::ifstream file(path);
    return file.good();
}

} // namespace superfast
