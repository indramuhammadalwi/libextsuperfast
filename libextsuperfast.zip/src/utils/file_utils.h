#ifndef FILE_UTILS_H
#define FILE_UTILS_H

#include <string>

namespace superfast {

class FileUtils {
public:
    static bool fileExists(const std::string& path);
};

} // namespace superfast

#endif // FILE_UTILS_H
