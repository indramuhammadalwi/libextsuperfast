#ifndef JSON_PARSER_H
#define JSON_PARSER_H

#include <string>
#include <map>

namespace superfast {

class JSONParser {
public:
    static std::map<std::string, std::string> parse(const std::string& jsonString);
};

} // namespace superfast

#endif // JSON_PARSER_H
