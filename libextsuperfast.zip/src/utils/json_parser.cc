#include "json_parser.h"
#include <iostream>
#include <sstream>

namespace superfast {

std::map<std::string, std::string> JSONParser::parse(const std::string& jsonString) {
    // Dummy implementation for JSON parsing
    std::map<std::string, std::string> result;
    std::istringstream ss(jsonString);
    std::string key, value;

    while (ss >> key >> value) {
        result[key] = value;
    }

    return result;
}

} // namespace superfast
