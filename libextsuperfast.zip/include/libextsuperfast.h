#ifndef LIBEXTSUPERFAST_H
#define LIBEXTSUPERFAST_H

#include <string>
#include <vector>

namespace superfast {

struct Extension {
    std::string id;
    std::string name;
    std::string version;
    bool is_active;
};

class ExtensionManager {
public:
    bool installFromWebStore(const std::string& extensionId);
    bool installFromCRX(const std::string& filePath);
    bool installFromZIP(const std::string& filePath);
    std::vector<Extension> listExtensions();
    bool runExtension(const std::string& extensionId);
};

} // namespace superfast

#endif // LIBEXTSUPERFAST_H
