#ifndef CONFIG_H
#define CONFIG_H

#define EXTENSION_STORAGE_PATH "/data/data/com.superfast/extensions/"
#define CHROME_WEBSTORE_URL "https://chrome.google.com/webstore/"

#endif // CONFIG_H
